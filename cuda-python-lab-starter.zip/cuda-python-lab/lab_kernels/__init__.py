"""CUDA Python lab kernels."""
